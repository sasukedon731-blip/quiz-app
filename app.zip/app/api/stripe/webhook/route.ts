// app/api/stripe/webhook/route.ts
import Stripe from "stripe"
import { headers } from "next/headers"
import { NextResponse } from "next/server"
import { setUserBillingMerge, setUserIndustryMerge } from "@/app/lib/billingServer"

export const runtime = "nodejs"

function addDays(date: Date, days: number) {
  const d = new Date(date)
  d.setDate(d.getDate() + days)
  return d
}

function parseDurationDays(v: any): 30 | 180 | 365 {
  const n = Number(v)
  return n === 180 ? 180 : n === 365 ? 365 : 30
}

function parsePlan(v: any): "3" | "5" | "7" | null {
  return v === "3" || v === "5" || v === "7" ? v : null
}

function parseAiConversation(v: any): boolean {
  return v === true || v === "true"
}

function parseMethod(v: any): "convenience" | "card" {
  return v === "convenience" ? "convenience" : "card"
}

type IndustryId =
  | "construction"
  | "manufacturing"
  | "care"
  | "driver"
  | "undecided"

function parseIndustry(v: any): IndustryId | null {
  return v === "construction" ||
    v === "manufacturing" ||
    v === "care" ||
    v === "driver" ||
    v === "undecided"
    ? v
    : null
}

export async function POST(req: Request) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
    apiVersion: "2026-02-25.clover",
  })

  const sig = (await headers()).get("stripe-signature")
  if (!sig)
    return NextResponse.json(
      { error: "Missing stripe-signature" },
      { status: 400 }
    )

  const rawBody = await req.text()

  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(
      rawBody,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    )
  } catch (err: any) {
    console.error("Webhook signature verification failed.", err?.message)
    return NextResponse.json({ error: "Bad signature" }, { status: 400 })
  }

  try {
    switch (event.type) {
      // Checkout completed (customer finished hosted flow).
      // For async methods (konbini), payment might still be unpaid here.
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session

        const uid = (session.metadata?.uid || session.client_reference_id) as
          | string
          | undefined
        if (!uid) break

        const plan = parsePlan(session.metadata?.plan)
        const method = parseMethod(session.metadata?.method)
        const durationDays = parseDurationDays(session.metadata?.durationDays)
        const industry = parseIndustry(session.metadata?.industry)
        const addAiConversation = parseAiConversation(session.metadata?.addAiConversation)

        const paid = session.payment_status === "paid"

        await setUserBillingMerge(uid, {
          accountType: "personal",
          method,
          status: paid ? "active" : "pending",
          stripeCheckoutSessionId: session.id,
          stripePaymentIntentId:
            typeof session.payment_intent === "string"
              ? session.payment_intent
              : null,
          ...(plan ? { currentPlan: plan } : {}),
          currentPeriodEnd: paid ? addDays(new Date(), durationDays) : null,
          aiConversationEnabled: paid ? addAiConversation : false,
          aiConversationExpiresAt: paid && addAiConversation ? addDays(new Date(), durationDays) : null,
        })

        // ✅ ここが追加：paid のときだけ industry を確定保存
        if (paid && industry) {
          await setUserIndustryMerge(uid, industry)
        }

        break
      }

      // Payment succeeded (card immediately, konbini after customer pays at store)
      case "payment_intent.succeeded": {
        const pi = event.data.object as Stripe.PaymentIntent
        const uid = pi.metadata?.uid as string | undefined
        if (!uid) break

        const plan = parsePlan(pi.metadata?.plan)
        const method = parseMethod(pi.metadata?.method)
        const durationDays = parseDurationDays(pi.metadata?.durationDays)
        const industry = parseIndustry(pi.metadata?.industry)
        const addAiConversation = parseAiConversation(pi.metadata?.addAiConversation)

        await setUserBillingMerge(uid, {
          accountType: "personal",
          method,
          status: "active",
          stripePaymentIntentId: pi.id,
          ...(plan ? { currentPlan: plan } : {}),
          currentPeriodEnd: addDays(new Date(), durationDays),
          aiConversationEnabled: addAiConversation,
          aiConversationExpiresAt: addAiConversation ? addDays(new Date(), durationDays) : null,
        })

        // ✅ ここが本命：最終確定タイミングで industry 保存
        if (industry) {
          await setUserIndustryMerge(uid, industry)
        }

        break
      }

      case "payment_intent.payment_failed": {
        const pi = event.data.object as Stripe.PaymentIntent
        const uid = pi.metadata?.uid as string | undefined
        if (uid) {
          await setUserBillingMerge(uid, {
            status: "past_due",
            stripePaymentIntentId: pi.id,
          })
        }
        break
      }

      default:
        break
    }

    return NextResponse.json({ received: true }, { status: 200 })
  } catch (e: any) {
    console.error("Webhook handler error:", e)
    return NextResponse.json(
      { error: e?.message ?? "Webhook error" },
      { status: 500 }
    )
  }
}